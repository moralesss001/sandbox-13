# RR Replay Old Sample Report

**Status:** READY

- journal: `data/journals/signals_export_1897339801.csv`
- candles_root: `data/candles/binance_futures/15m`
- merged_candles_csv: `data/candles/binance_futures/15m/merged_old_sample_15m_candles.csv`
- input trades count: `98`
- same-candle policy: conservative, TP+SL in one candle is counted as SL and flagged.
- warning: research-only; not a production decision.

## Mode Results

| mode | evaluated | skipped | wins | losses | open | winrate | PF | expectancy_R | net_R | max_dd_R | max_loss_streak | same_candle_conflicts | avg_MAE_R | avg_MFE_R |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| rr_1_0 | 98 | 0 | 37 | 61 | 0 | 37.76% | 0.6066 | -0.2449 | -24.0000 | 25.0000 | 10 | 0 | -1.1251 | 0.6715 |
| rr_1_1 | 98 | 0 | 31 | 67 | 0 | 31.63% | 0.5090 | -0.3357 | -32.9000 | 34.0000 | 18 | 0 | -1.1705 | 0.6953 |
| rr_1_3 | 98 | 0 | 31 | 67 | 0 | 31.63% | 0.6015 | -0.2724 | -26.7000 | 28.0000 | 18 | 0 | -1.1705 | 0.7582 |
| rr_1_5 | 98 | 0 | 26 | 72 | 0 | 26.53% | 0.5417 | -0.3367 | -33.0000 | 34.5000 | 27 | 0 | -1.2141 | 0.8055 |
| tp_1r_sl_0_5r | 98 | 0 | 3 | 95 | 0 | 3.06% | 0.0632 | -0.9082 | -89.0000 | 89.0000 | 52 | 0 | -1.5835 | 0.4819 |
| tp_1r_sl_0_75r | 98 | 0 | 21 | 77 | 0 | 21.43% | 0.3636 | -0.5000 | -49.0000 | 49.0000 | 11 | 0 | -1.3081 | 0.6574 |

## Best Modes

- best mode by expectancy_R: `rr_1_0`
- best mode by PF: `rr_1_0`

## Skip Reasons

```json
{
  "rr_1_0": {},
  "rr_1_1": {},
  "rr_1_3": {},
  "rr_1_5": {},
  "tp_1r_sl_0_5r": {},
  "tp_1r_sl_0_75r": {}
}
```

## MAE/MFE Summary

MAE is negative adverse movement in R. MFE is favorable movement in R before exit/data end.

## Safety

- No hypothesis conclusions were moved to production.
- No live paper mode was started.
- No real orders were sent.
- No testnet orders were sent.