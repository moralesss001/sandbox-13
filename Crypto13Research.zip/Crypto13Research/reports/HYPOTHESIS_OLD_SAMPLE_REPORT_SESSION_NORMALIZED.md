# Hypothesis Old Sample Report — Session Normalized

**Status:** READY

- normalization: `EU -> EUROPE`, `EUROPE -> EUROPE`, `US -> US`, `EU_US -> OVERLAP`, `ASIA -> ASIA`
- input/evaluated/skipped: `98/98/0`
- baseline replay mode: `rr_1_5`
- warning: research-only; no strategy or production decision.

## Session Counts

Raw: `{"US": 51, "EU_US": 20, "ASIA": 14, "EU": 13}`

Normalized: `{"OVERLAP": 20, "US": 51, "ASIA": 14, "EUROPE": 13}`

## Session Breakdown

| session | trades | wins | losses | winrate | PF | expectancy_R | net_R |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ASIA | 14 | 4 | 10 | 28.57% | 0.6000 | -0.2857 | -4.00 |
| EUROPE | 13 | 1 | 12 | 7.69% | 0.1250 | -0.8077 | -10.50 |
| OVERLAP | 20 | 2 | 18 | 10.00% | 0.1667 | -0.7500 | -15.00 |
| US | 51 | 19 | 32 | 37.25% | 0.8906 | -0.0686 | -3.50 |

## Baseline Current

```json
{
  "trades": 98,
  "wins": 26,
  "losses": 72,
  "open": 0,
  "winrate": 26.53061224489796,
  "profit_factor": 0.5416666666666666,
  "expectancy_R": -0.336734693877551,
  "net_R": -33.0,
  "max_drawdown_R": 34.5,
  "max_loss_streak": 27,
  "hypothesis_id": "baseline_current",
  "allowed_trades": 98,
  "blocked_trades": 0,
  "blocked_losses": 0,
  "missed_wins": 0,
  "blocked_net_R": 0
}
```

## Active Hypothesis Leaderboard

| hypothesis | allowed | blocked | wins | losses | winrate | PF | expectancy_R | net_R | blocked_losses | missed_wins |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| allow_only_continuation | 4 | 94 | 4 | 0 | 100.00% | 6.0000 | 1.5000 | 6.00 | 72 | 22 |
| allow_us_unknown | 49 | 49 | 17 | 32 | 34.69% | 0.7969 | -0.1327 | -6.50 | 40 | 9 |
| ban_rsi_below_40 | 50 | 48 | 17 | 33 | 34.00% | 0.7727 | -0.1500 | -7.50 | 39 | 9 |
| ban_unclear_low_rsi | 50 | 48 | 17 | 33 | 34.00% | 0.7727 | -0.1500 | -7.50 | 39 | 9 |
| allow_only_mid_rsi | 50 | 48 | 17 | 33 | 34.00% | 0.7727 | -0.1500 | -7.50 | 39 | 9 |
| ban_rsi_below_35 | 71 | 27 | 23 | 48 | 32.39% | 0.7188 | -0.1901 | -13.50 | 24 | 3 |
| ban_overlap | 78 | 20 | 24 | 54 | 30.77% | 0.6667 | -0.2308 | -18.00 | 18 | 2 |
| ban_unclear_overlap | 78 | 20 | 24 | 54 | 30.77% | 0.6667 | -0.2308 | -18.00 | 18 | 2 |
| ban_rsi_below_38 | 60 | 38 | 18 | 42 | 30.00% | 0.6429 | -0.2500 | -15.00 | 30 | 8 |
| ban_unclear_europe_rebound | 88 | 10 | 26 | 62 | 29.55% | 0.6290 | -0.2614 | -23.00 | 10 | 0 |
| ban_rebound_europe | 88 | 10 | 26 | 62 | 29.55% | 0.6290 | -0.2614 | -23.00 | 10 | 0 |
| ban_unclear_europe | 85 | 13 | 25 | 60 | 29.41% | 0.6250 | -0.2647 | -22.50 | 12 | 1 |
| ban_low_rsi_europe | 89 | 9 | 26 | 63 | 29.21% | 0.6190 | -0.2697 | -24.00 | 9 | 0 |
| ban_europe_low_rsi | 89 | 9 | 26 | 63 | 29.21% | 0.6190 | -0.2697 | -24.00 | 9 | 0 |
| baseline_rr15 | 98 | 0 | 26 | 72 | 26.53% | 0.5417 | -0.3367 | -33.00 | 0 | 0 |

## Requested Analysis

```json
{
  "session_breakdown": {
    "ASIA": {
      "trades": 14,
      "wins": 4,
      "losses": 10,
      "open": 0,
      "winrate": 28.57142857142857,
      "profit_factor": 0.6,
      "expectancy_R": -0.2857142857142857,
      "net_R": -4.0,
      "max_drawdown_R": 9.0,
      "max_loss_streak": 9
    },
    "EUROPE": {
      "trades": 13,
      "wins": 1,
      "losses": 12,
      "open": 0,
      "winrate": 7.6923076923076925,
      "profit_factor": 0.125,
      "expectancy_R": -0.8076923076923077,
      "net_R": -10.5,
      "max_drawdown_R": 10.5,
      "max_loss_streak": 8
    },
    "OVERLAP": {
      "trades": 20,
      "wins": 2,
      "losses": 18,
      "open": 0,
      "winrate": 10.0,
      "profit_factor": 0.16666666666666666,
      "expectancy_R": -0.75,
      "net_R": -15.0,
      "max_drawdown_R": 16.5,
      "max_loss_streak": 10
    },
    "US": {
      "trades": 51,
      "wins": 19,
      "losses": 32,
      "open": 0,
      "winrate": 37.254901960784316,
      "profit_factor": 0.890625,
      "expectancy_R": -0.06862745098039216,
      "net_R": -3.5,
      "max_drawdown_R": 15.0,
      "max_loss_streak": 15
    }
  },
  "rsi_buckets": {
    "LOW_<40": {
      "trades": 48,
      "wins": 9,
      "losses": 39,
      "open": 0,
      "winrate": 18.75,
      "profit_factor": 0.34615384615384615,
      "expectancy_R": -0.53125,
      "net_R": -25.5,
      "max_drawdown_R": 25.5,
      "max_loss_streak": 14
    },
    "MID_40_65": {
      "trades": 50,
      "wins": 17,
      "losses": 33,
      "open": 0,
      "winrate": 34.0,
      "profit_factor": 0.7727272727272727,
      "expectancy_R": -0.15,
      "net_R": -7.5,
      "max_drawdown_R": 15.5,
      "max_loss_streak": 13
    },
    "HIGH_>65": {
      "trades": 0,
      "wins": 0,
      "losses": 0,
      "open": 0,
      "winrate": 0.0,
      "profit_factor": 0.0,
      "expectancy_R": 0.0,
      "net_R": 0,
      "max_drawdown_R": 0.0,
      "max_loss_streak": 0
    }
  },
  "htf_short_vs_15m_long": {
    "trades": 85,
    "wins": 22,
    "losses": 63,
    "open": 0,
    "winrate": 25.882352941176475,
    "profit_factor": 0.5238095238095238,
    "expectancy_R": -0.35294117647058826,
    "net_R": -30.0,
    "max_drawdown_R": 31.5,
    "max_loss_streak": 22
  },
  "market_phase_unclear": {
    "trades": 92,
    "wins": 23,
    "losses": 69,
    "open": 0,
    "winrate": 25.0,
    "profit_factor": 0.5,
    "expectancy_R": -0.375,
    "net_R": -34.5,
    "max_drawdown_R": 36.0,
    "max_loss_streak": 24
  },
  "setup_type": {
    "continuation": {
      "trades": 4,
      "wins": 4,
      "losses": 0,
      "open": 0,
      "winrate": 100.0,
      "profit_factor": 6.0,
      "expectancy_R": 1.5,
      "net_R": 6.0,
      "max_drawdown_R": 0.0,
      "max_loss_streak": 0
    },
    "rebound": {
      "trades": 67,
      "wins": 16,
      "losses": 51,
      "open": 0,
      "winrate": 23.88059701492537,
      "profit_factor": 0.47058823529411764,
      "expectancy_R": -0.40298507462686567,
      "net_R": -27.0,
      "max_drawdown_R": 28.5,
      "max_loss_streak": 17
    },
    "unknown": {
      "trades": 27,
      "wins": 6,
      "losses": 21,
      "open": 0,
      "winrate": 22.22222222222222,
      "profit_factor": 0.42857142857142855,
      "expectancy_R": -0.4444444444444444,
      "net_R": -12.0,
      "max_drawdown_R": 12.0,
      "max_loss_streak": 11
    }
  },
  "time_after_14_msk": {
    "trades": 71,
    "wins": 21,
    "losses": 50,
    "open": 0,
    "winrate": 29.577464788732392,
    "profit_factor": 0.63,
    "expectancy_R": -0.2605633802816901,
    "net_R": -18.5,
    "max_drawdown_R": 23.0,
    "max_loss_streak": 15
  },
  "clusters": {
    "unclear + EUROPE + rebound": {
      "trades": 10,
      "wins": 0,
      "losses": 10,
      "open": 0,
      "winrate": 0.0,
      "profit_factor": 0.0,
      "expectancy_R": -1.0,
      "net_R": -10.0,
      "max_drawdown_R": 10.0,
      "max_loss_streak": 10
    },
    "unclear + HTF Short + unknown": {
      "trades": 18,
      "wins": 5,
      "losses": 13,
      "open": 0,
      "winrate": 27.77777777777778,
      "profit_factor": 0.5769230769230769,
      "expectancy_R": -0.3055555555555556,
      "net_R": -5.5,
      "max_drawdown_R": 8.0,
      "max_loss_streak": 8
    }
  }
}
```

## Safety

- Production Crypto13 was not touched.
- Binance live paper was not started.
- No real or testnet orders were added or sent.
- Strategy logic was not changed.