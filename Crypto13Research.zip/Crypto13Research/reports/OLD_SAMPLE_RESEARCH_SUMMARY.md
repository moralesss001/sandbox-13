# Old Sample Research Summary

**Was old sample fully replayed?** READY

- evaluated trades: `98`
- skipped trades: `0`
- best RR mode by expectancy_R: `rr_1_0`
- best RR mode by PF: `rr_1_0`
- RR 1.5 looks `worse` than RR 1.1 by expectancy_R on this old sample.
- TP 1R / SL 0.5R `damaged` results vs RR 1.5 by expectancy_R on this old sample.

## Strongest Toxic Clusters

| combination | trades | winrate | expectancy_R | net_R |
| --- | --- | --- | --- | --- |
| unclear + US + rebound | 39 | 28.21% | -0.2949 | -11.5000 |
| unclear + US + rebound + Short | 36 | 27.78% | -0.3056 | -11.0000 |
| unclear + EU + rebound | 10 | 0.00% | -1.0000 | -10.0000 |
| unclear + EU + rebound + Short | 9 | 0.00% | -1.0000 | -9.0000 |
| unclear + EU_US + unknown | 8 | 0.00% | -1.0000 | -8.0000 |
| unclear + EU_US + rebound | 12 | 16.67% | -0.5833 | -7.0000 |
| unclear + EU_US + rebound + Short | 12 | 16.67% | -0.5833 | -7.0000 |
| unclear + EU_US + unknown + Short | 7 | 0.00% | -1.0000 | -7.0000 |

## Strongest Positive Clusters

| combination | trades | winrate | expectancy_R | net_R |
| --- | --- | --- | --- | --- |
| unclear + US + unknown + Short | 7 | 71.43% | 0.7857 | 5.5000 |
| unclear + US + unknown | 9 | 55.56% | 0.3889 | 3.5000 |

## Top 3 Hypotheses Worth Further Testing

- `allow_only_continuation`: expectancy_R `1.5000`, net_R `6.0000`, blocked `94`
- `setup_continuation`: expectancy_R `1.5000`, net_R `6.0000`, blocked `94`
- `rsi_bucket_high`: expectancy_R `0.0000`, net_R `0`, blocked `98`

## What Should NOT Be Moved To Production Yet

- Do not move any auto-filter or RR change to production from this old sample alone.
- Do not enable Binance live paper from this task.
- Do not send real or testnet orders.
- Do not change production Crypto13 strategy logic.

## Report Paths

- `reports/RR_REPLAY_OLD_SAMPLE_REPORT.md`
- `reports/RR_REPLAY_OLD_SAMPLE_REPORT.json`
- `reports/HYPOTHESIS_OLD_SAMPLE_REPORT.md`
- `reports/HYPOTHESIS_OLD_SAMPLE_REPORT.json`