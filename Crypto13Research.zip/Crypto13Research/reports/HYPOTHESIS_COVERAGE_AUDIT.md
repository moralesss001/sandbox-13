# Hypothesis Coverage Audit

**Status:** READY

- scope: audit/report only
- old closed trades audited: `98`
- configured hypotheses audited: `15`
- valid hypotheses: `15`
- zero-sample hypotheses: `0`
- Research Pack 2: **not added and not proposed per user instruction**

## Existing Hypothesis Inventory And Validity

| hypothesis_id | mode | fields | filters | expected values | valid | matching rows | blocked rows | evaluated rows | reason |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline_rr15 | baseline | - | allow_all | all | true | 98 | 0 | 98 | valid_and_has_sample |
| ban_rsi_below_35 | block_filter | rsi | rsi >= 35 | rsi < 35 | true | 71 | 27 | 71 | valid_and_has_sample |
| ban_rsi_below_38 | block_filter | rsi | rsi >= 38 | rsi < 38 | true | 60 | 38 | 60 | valid_and_has_sample |
| ban_rsi_below_40 | block_filter | rsi | rsi >= 40 | rsi < 40 | true | 50 | 48 | 50 | valid_and_has_sample |
| ban_unclear_europe_rebound | block_filter | market_phase, session_msk, setup_type | market_phase != unclear OR session != europe OR setup != rebound | unclear, EUROPE, rebound | true | 88 | 10 | 88 | valid_and_has_sample |
| ban_overlap | block_filter | session_msk | session != overlap | OVERLAP | true | 78 | 20 | 78 | valid_and_has_sample |
| ban_unclear_low_rsi | block_filter | market_phase, rsi | market_phase != unclear OR rsi >= 40 | unclear, rsi < 40 | true | 50 | 48 | 50 | valid_and_has_sample |
| ban_low_rsi_europe | block_filter | session_msk, rsi | session != europe OR rsi >= 40 | EUROPE, rsi < 40 | true | 89 | 9 | 89 | valid_and_has_sample |
| ban_rebound_europe | block_filter | session_msk, setup_type | session != europe OR setup != rebound | EUROPE, rebound | true | 88 | 10 | 88 | valid_and_has_sample |
| ban_unclear_europe | block_filter | session_msk, market_phase | session != europe OR market_phase != unclear | EUROPE, unclear | true | 85 | 13 | 85 | valid_and_has_sample |
| allow_only_mid_rsi | allow_only | rsi | 40 <= rsi <= 65 | 40..65 | true | 50 | 48 | 50 | valid_and_has_sample |
| allow_only_continuation | allow_only | setup_type | setup_type == continuation | continuation | true | 4 | 94 | 4 | valid_and_has_sample |
| allow_us_unknown | allow_only | session_msk, market_phase | session == US AND market_phase in unknown/unclear | US, unknown\|unclear | true | 49 | 49 | 49 | valid_and_has_sample |
| ban_unclear_overlap | block_filter | market_phase, session_msk | market_phase != unclear OR session != overlap | unclear, OVERLAP | true | 78 | 20 | 78 | valid_and_has_sample |
| ban_europe_low_rsi | block_filter | session_msk, rsi | session != europe OR rsi >= 40 | EUROPE, rsi < 40 | true | 89 | 9 | 89 | valid_and_has_sample |

## Data Field Coverage

| field | exists | actual field | non-empty | unique | top values |
| --- | --- | --- | --- | --- | --- |
| symbol | yes | symbol | 98 | 38 | {"GRTUSDT": 6, "DOTUSDT": 5, "KASUSDT": 5, "LINKUSDT": 5, "IMXUSDT": 5, "UNIUSDT": 4, "TIAUSDT": 4, "CRVUSDT": 3, "FILUSDT": 3, "SEIUSDT": 3} |
| timeframe | yes | timeframe | 98 | 1 | {"15m": 98} |
| side | yes | direction | 98 | 1 | {"LONG": 98} |
| session | no | - | 0 | 0 | {} |
| session_msk | yes | session_msk | 98 | 4 | {"US": 51, "EU_US": 20, "ASIA": 14, "EU": 13} |
| hour_msk | yes | hour_msk | 98 | 15 | {"17.0": 24, "18.0": 16, "15.0": 10, "1.0": 9, "16.0": 8, "19.0": 6, "11.0": 6, "13.0": 4, "22.0": 3, "0.0": 3} |
| market_phase | yes | market_phase | 98 | 3 | {"unclear": 92, "range": 5, "trend": 1} |
| market_mode | yes | market_mode | 98 | 2 | {"IMPULSE_CONTINUATION:pullback_impulse": 81, "EXTREME_REVERSION:extreme_reversion_long": 17} |
| setup_type | yes | setup_type | 98 | 3 | {"rebound": 67, "unknown": 27, "continuation": 4} |
| trend_htf | yes | trend_htf | 98 | 2 | {"Short": 85, "Long": 13} |
| rsi | yes | rsi | 98 | 90 | {"32.0": 3, "43.59": 2, "30.43": 2, "31.43": 2, "33.08": 2, "31.85": 2, "30.47": 2, "36.24": 1, "48.72": 1, "48.41": 1} |
| atr_pct | yes | atr_pct | 98 | 98 | {"0.0052865553286074": 1, "0.007900350724952": 1, "0.0094862931103786": 1, "0.0065290873510051": 1, "0.0071740486587647": 1, "0.0058539466370205": 1, "0.0111459968602825": 1, "0.0092943201376936": 1, "0.009080509080509": 1, "0.0070717402074377": 1} |
| score | yes | score | 98 | 23 | {"100": 11, "87": 10, "88": 9, "71": 8, "70": 8, "86": 6, "84": 4, "92": 4, "94": 4, "85": 4} |
| entry_time | yes | candle_open_time_utc | 98 | 47 | {"2026-06-01 15:30:00": 9, "2026-06-01 12:15:00": 8, "2026-06-02 14:30:00": 8, "2026-05-29 14:45:00": 6, "2026-06-02 14:45:00": 4, "2026-06-01 22:45:00": 4, "2026-06-01 13:30:00": 4, "2026-06-01 08:30:00": 4, "2026-06-02 10:00:00": 3, "2026-05-29 22:15:00": 3} |
| result/outcome | yes | result | 98 | 2 | {"SL": 64, "TP": 34} |

## Exact Duplicate / Equivalent Hypotheses On This Sample

| hypotheses | matching rows | blocked rows | identical result |
| --- | --- | --- | --- |
| ban_rsi_below_40 = ban_unclear_low_rsi = allow_only_mid_rsi | 50 | 48 | yes |
| ban_unclear_europe_rebound = ban_rebound_europe | 88 | 10 | yes |
| ban_overlap = ban_unclear_overlap | 78 | 20 | yes |
| ban_low_rsi_europe = ban_europe_low_rsi | 89 | 9 | yes |

Important: sample-equivalent masks can diverge on future data.

## Near-Duplicate Pairs

| hypotheses | different rows | left matching | right matching |
| --- | --- | --- | --- |
| ban_low_rsi_europe ~ ban_rebound_europe | 1 | 89 | 88 |
| ban_rebound_europe ~ ban_europe_low_rsi | 1 | 88 | 89 |
| ban_unclear_europe_rebound ~ ban_europe_low_rsi | 1 | 88 | 89 |
| ban_unclear_europe_rebound ~ ban_low_rsi_europe | 1 | 88 | 89 |
| ban_rebound_europe ~ ban_unclear_europe | 3 | 88 | 85 |
| ban_unclear_europe_rebound ~ ban_unclear_europe | 3 | 88 | 85 |
| ban_low_rsi_europe ~ ban_unclear_europe | 4 | 89 | 85 |
| ban_unclear_europe ~ ban_europe_low_rsi | 4 | 85 | 89 |

## Missing Hypotheses Audit

| category | hypothesis_id | status | coverage or blocker |
| --- | --- | --- | --- |
| Entry / setup | allow_only_breakout_continuation | missing | - |
| Entry / setup | allow_only_pullback_after_impulse | missing | - |
| Entry / setup | ban_rebound_without_htf_support | missing | - |
| Entry / setup | ban_unknown_setup | missing | - |
| Entry / setup | ban_entry_against_recent_impulse | missing | - |
| Entry / setup | ban_late_entry_after_large_candle | missing | - |
| HTF | allow_long_only_if_htf_not_short | missing | - |
| HTF | allow_long_only_if_1h_trend_long | blocked_by_missing_field | separate 1h trend field missing |
| HTF | allow_long_only_if_4h_trend_not_short | blocked_by_missing_field | separate 4h trend field missing |
| HTF | ban_15m_long_when_1h_and_4h_both_short | blocked_by_missing_field | separate 1h and 4h trend fields missing |
| HTF | allow_countertrend_only_in_us_session | missing | - |
| HTF | allow_countertrend_only_if_rsi_mid | missing | - |
| Session | ban_europe | missing | - |
| Session | ban_overlap | present | ban_overlap |
| Session | allow_only_us | partially_covered | allow_us_unknown |
| Session | allow_us_and_asia_only | missing | - |
| Session | ban_europe_rebound | partially_covered | ban_rebound_europe |
| Session | ban_overlap_rebound | missing | - |
| Session | ban_europe_unknown | missing | - |
| Session | ban_overlap_unknown | missing | - |
| Session | allow_us_continuation_only | missing | - |
| Time windows | hour_10_14_msk | missing | - |
| Time windows | hour_14_17_msk | missing | - |
| Time windows | hour_17_20_msk | missing | - |
| Time windows | hour_20_23_msk | missing | - |
| Time windows | ban_first_hour_of_session | missing | - |
| Time windows | ban_last_hour_before_overlap | missing | - |
| Time windows | allow_only_high_liquidity_window | missing | - |
| RSI | ban_rsi_below_40 | present | ban_rsi_below_40 |
| RSI | allow_rsi_40_55 | partially_covered | allow_only_mid_rsi |
| RSI | allow_rsi_45_60 | missing | - |
| RSI | ban_rsi_above_60_for_long_if_late_impulse | missing | - |
| RSI | allow_rebound_only_rsi_40_55 | missing | - |
| RSI | allow_continuation_only_rsi_45_65 | missing | - |
| MAE/MFE diagnostics | mfe_reaches_0_5r_before_sl | missing | - |
| MAE/MFE diagnostics | mfe_reaches_0_75r_before_sl | missing | - |
| MAE/MFE diagnostics | mfe_reaches_1r_before_sl | missing | - |
| MAE/MFE diagnostics | mae_less_than_0_5r_before_tp | missing | - |
| MAE/MFE diagnostics | mae_less_than_0_75r_before_tp | missing | - |
| ATR / volatility | ban_low_atr | missing | - |
| ATR / volatility | ban_extreme_atr | missing | - |
| ATR / volatility | allow_mid_atr_only | missing | - |
| ATR / volatility | low_atr_rebound_toxic | missing | - |
| ATR / volatility | low_atr_unknown_toxic | missing | - |
| ATR / volatility | high_atr_late_entry_toxic | missing | - |
| Symbols | symbol_leaderboard | missing | - |
| Symbols | ban_bottom_symbols | missing | - |
| Symbols | allow_top_liquidity_symbols_only | blocked_by_missing_field | liquidity universe/metric missing |
| Symbols | large_caps_vs_alts | missing | - |
| Symbols | btc_eth_sol_only | missing | - |
| Symbols | exclude_low_quality_symbols | blocked_by_missing_field | quality classification missing |
| Market mode | market_mode_pullback_impulse | missing | - |
| Market mode | market_mode_trend | missing | - |
| Market mode | market_mode_range | missing | - |
| Market mode | market_mode_no_trade | missing | - |
| Market mode | ban_market_mode_no_trade | missing | - |
| Market mode | ban_pullback_impulse_if_htf_short | missing | - |
| Market mode | allow_pullback_impulse_only_us | missing | - |
| Rejected signals | replay_rejected_rsi_below_35 | blocked_by_missing_field | rejected-signals dataset not supplied; journal has only 7 SKIP rows without replay outcome |
| Rejected signals | compare_blocked_rsi35_tp_vs_sl | blocked_by_missing_field | rejected-signals post-entry outcome not available |
| Rejected signals | missed_profit_from_rejections | blocked_by_missing_field | rejected-signals post-entry outcome not available |
| Rejected signals | saved_loss_from_rejections | blocked_by_missing_field | rejected-signals post-entry outcome not available |

## Research Pack 2

Not added and no ranked proposal generated in this task, per explicit user instruction.

## Interpretation Safety

### What we can say now

- All 15 configured hypotheses are implemented and match available journal fields.
- Some hypotheses are empirically equivalent on this 98-trade sample.
- Continuation has only 4 matching trades and is unsafe to generalize.
- Normalized EUROPE and OVERLAP categories now have valid sample attribution.

### What we cannot say yet

- No hypothesis can be promoted to production from one old sample.
- Equivalent masks on this sample do not prove logical equivalence on future data.
- Separate 1h and 4h HTF rules cannot be evaluated from the current combined trend_htf field.

### What requires live paper

- Prospective behavior of filters under fresh signals and current market regimes.
- Operational event coverage and portfolio effects without historical-result leakage.

### What requires a new production sample

- Confirmation of toxic session/setup clusters on the completed RR 1.5 sample.
- Larger continuation sample and stability across journal versions.

### What should not be moved to production

- Any automatic ban/filter/risk change.
- Continuation-only logic based on 4 trades.
- Symbol exclusions or HTF filters without adequate fields and sample size.

## Safety Confirmation

- Production Crypto13 was not touched.
- Binance API was not connected.
- Live paper was not started.
- No real or testnet orders were added or sent.
- No strategy logic was changed.