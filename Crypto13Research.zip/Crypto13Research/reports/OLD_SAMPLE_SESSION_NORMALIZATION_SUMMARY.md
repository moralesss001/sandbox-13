# Old Sample Session Normalization Summary

**Status:** READY

- old sample fully replayed: `True`
- evaluated/skipped: `98/0`
- corrected mapping: `EU_US -> OVERLAP`
- existing mapping confirmed: `EU -> EUROPE`

## Normalized Distribution

- `ASIA`: `14` trades
- `EUROPE`: `13` trades
- `OVERLAP`: `20` trades
- `US`: `51` trades

## Hypotheses Changed By Normalization

| hypothesis | allowed_before | allowed_after | net_R_before | net_R_after |
| --- | --- | --- | --- | --- |
| ban_unclear_europe_rebound | 98 | 88 | -33.00 | -23.00 |
| ban_low_rsi_europe | 98 | 89 | -33.00 | -24.00 |
| ban_rebound_europe | 98 | 88 | -33.00 | -23.00 |
| ban_unclear_europe | 98 | 85 | -33.00 | -22.50 |
| ban_europe_low_rsi | 98 | 89 | -33.00 | -24.00 |

## Interpretation Boundary

- This fixes category attribution only.
- It does not validate or promote any filter.
- Nothing from this report should be moved to production yet.

## Reports

- `reports/HYPOTHESIS_OLD_SAMPLE_REPORT_SESSION_NORMALIZED.md`
- `reports/HYPOTHESIS_OLD_SAMPLE_REPORT_SESSION_NORMALIZED.json`