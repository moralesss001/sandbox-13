# Hypothesis Old Sample Report

**Status:** READY

- config: `config/hypotheses.yaml`
- baseline mode: `rr_1_5`
- warning: research-only; hypotheses are not production rules.

## Baseline Current

```json
{
  "input_trades_count": 98,
  "evaluated_trades_count": 98,
  "skipped_trades_count": 0,
  "skip_reasons": {},
  "wins": 26,
  "losses": 72,
  "open": 0,
  "winrate": 26.53061224489796,
  "profit_factor": 0.5416666666666666,
  "expectancy_R": -0.336734693877551,
  "net_R": -33.0,
  "gross_win_R": 39.0,
  "gross_loss_R": 72.0,
  "max_drawdown_R": 34.5,
  "max_loss_streak": 27,
  "mae_summary": {
    "avg_MAE_R": -1.2141064076144943,
    "worst_MAE_R": -2.8249999999999917
  },
  "mfe_summary": {
    "avg_MFE_R": 0.8054702362456695,
    "best_MFE_R": 2.2957746478873364
  },
  "same_candle_conflicts": 0,
  "hypothesis_id": "baseline_current",
  "mode": "rr_1_5",
  "allowed_trades": 98,
  "blocked_trades": 0,
  "blocked_losses": 0,
  "missed_wins": 0,
  "blocked_net_R": 0
}
```

## Leaderboard

| hypothesis | allowed | blocked | wins | losses | winrate | PF | expectancy_R | net_R | blocked_losses | missed_wins |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| allow_only_continuation | 4 | 94 | 4 | 0 | 100.00% | 6.0000 | 1.5000 | 6.0000 | 72 | 22 |
| setup_continuation | 4 | 94 | 4 | 0 | 100.00% | 6.0000 | 1.5000 | 6.0000 | 72 | 22 |
| rsi_bucket_high | 0 | 98 | 0 | 0 | 0.00% | 0.0000 | 0.0000 | 0 | 72 | 26 |
| session_europe | 0 | 98 | 0 | 0 | 0.00% | 0.0000 | 0.0000 | 0 | 72 | 26 |
| cluster_unclear_europe_rebound | 0 | 98 | 0 | 0 | 0.00% | 0.0000 | 0.0000 | 0 | 72 | 26 |
| session_us | 51 | 47 | 19 | 32 | 37.25% | 0.8906 | -0.0686 | -3.5000 | 40 | 7 |
| allow_us_unknown | 49 | 49 | 17 | 32 | 34.69% | 0.7969 | -0.1327 | -6.5000 | 40 | 9 |
| ban_rsi_below_40 | 50 | 48 | 17 | 33 | 34.00% | 0.7727 | -0.1500 | -7.5000 | 39 | 9 |
| ban_unclear_low_rsi | 50 | 48 | 17 | 33 | 34.00% | 0.7727 | -0.1500 | -7.5000 | 39 | 9 |
| allow_only_mid_rsi | 50 | 48 | 17 | 33 | 34.00% | 0.7727 | -0.1500 | -7.5000 | 39 | 9 |
| rsi_bucket_mid | 50 | 48 | 17 | 33 | 34.00% | 0.7727 | -0.1500 | -7.5000 | 39 | 9 |
| ban_rsi_below_35 | 71 | 27 | 23 | 48 | 32.39% | 0.7188 | -0.1901 | -13.5000 | 24 | 3 |
| ban_overlap | 78 | 20 | 24 | 54 | 30.77% | 0.6667 | -0.2308 | -18.0000 | 18 | 2 |
| ban_unclear_overlap | 78 | 20 | 24 | 54 | 30.77% | 0.6667 | -0.2308 | -18.0000 | 18 | 2 |
| ban_rsi_below_38 | 60 | 38 | 18 | 42 | 30.00% | 0.6429 | -0.2500 | -15.0000 | 30 | 8 |
| time_after_14_msk | 71 | 27 | 21 | 50 | 29.58% | 0.6300 | -0.2606 | -18.5000 | 22 | 5 |
| session_asia | 14 | 84 | 4 | 10 | 28.57% | 0.6000 | -0.2857 | -4.0000 | 62 | 22 |
| cluster_unclear_htf_short_unknown | 18 | 80 | 5 | 13 | 27.78% | 0.5769 | -0.3056 | -5.5000 | 59 | 21 |
| baseline_current | 98 | 0 | 26 | 72 | 26.53% | 0.5417 | -0.3367 | -33.0000 | 0 | 0 |
| baseline_rr15 | 98 | 0 | 26 | 72 | 26.53% | 0.5417 | -0.3367 | -33.0000 | 0 | 0 |

## RR 1.1 / 1.3 / 1.5 Comparison

| mode | winrate | PF | expectancy_R | net_R | max_dd_R |
| --- | --- | --- | --- | --- | --- |
| rr_1_1 | 31.63% | 0.5090 | -0.3357 | -32.9000 | 34.0000 |
| rr_1_3 | 31.63% | 0.6015 | -0.2724 | -26.7000 | 28.0000 |
| rr_1_5 | 26.53% | 0.5417 | -0.3367 | -33.0000 | 34.5000 |

## TP/SL Comparison

| mode | winrate | PF | expectancy_R | net_R | max_dd_R |
| --- | --- | --- | --- | --- | --- |
| tp_1r_sl_0_5r | 3.06% | 0.0632 | -0.9082 | -89.0000 | 89.0000 |
| tp_1r_sl_0_75r | 21.43% | 0.3636 | -0.5000 | -49.0000 | 49.0000 |

## Requested Buckets And Clusters

```json
{
  "rsi_buckets": {
    "rsi_bucket_low": {
      "input_trades_count": 48,
      "evaluated_trades_count": 48,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 9,
      "losses": 39,
      "open": 0,
      "winrate": 18.75,
      "profit_factor": 0.34615384615384615,
      "expectancy_R": -0.53125,
      "net_R": -25.5,
      "gross_win_R": 13.5,
      "gross_loss_R": 39.0,
      "max_drawdown_R": 25.5,
      "max_loss_streak": 14,
      "mae_summary": {
        "avg_MAE_R": -1.2729231046478557,
        "worst_MAE_R": -2.8249999999999917
      },
      "mfe_summary": {
        "avg_MFE_R": 0.7086400873683382,
        "best_MFE_R": 1.8134715025906871
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "rsi_bucket_low",
      "mode": "rr_1_5",
      "allowed_trades": 48,
      "blocked_trades": 50,
      "blocked_losses": 33,
      "missed_wins": 17,
      "blocked_net_R": -7.5
    },
    "rsi_bucket_mid": {
      "input_trades_count": 50,
      "evaluated_trades_count": 50,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 17,
      "losses": 33,
      "open": 0,
      "winrate": 34.0,
      "profit_factor": 0.7727272727272727,
      "expectancy_R": -0.15,
      "net_R": -7.5,
      "gross_win_R": 25.5,
      "gross_loss_R": 33.0,
      "max_drawdown_R": 15.5,
      "max_loss_streak": 13,
      "mae_summary": {
        "avg_MAE_R": -1.1576423784624665,
        "worst_MAE_R": -2.2755417956656303
      },
      "mfe_summary": {
        "avg_MFE_R": 0.8984271791679095,
        "best_MFE_R": 2.2957746478873364
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "rsi_bucket_mid",
      "mode": "rr_1_5",
      "allowed_trades": 50,
      "blocked_trades": 48,
      "blocked_losses": 39,
      "missed_wins": 9,
      "blocked_net_R": -25.5
    },
    "rsi_bucket_high": {
      "input_trades_count": 0,
      "evaluated_trades_count": 0,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 0,
      "losses": 0,
      "open": 0,
      "winrate": 0.0,
      "profit_factor": 0.0,
      "expectancy_R": 0.0,
      "net_R": 0,
      "gross_win_R": 0,
      "gross_loss_R": 0,
      "max_drawdown_R": 0.0,
      "max_loss_streak": 0,
      "mae_summary": {
        "avg_MAE_R": 0.0,
        "worst_MAE_R": 0.0
      },
      "mfe_summary": {
        "avg_MFE_R": 0.0,
        "best_MFE_R": 0.0
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "rsi_bucket_high",
      "mode": "rr_1_5",
      "allowed_trades": 0,
      "blocked_trades": 98,
      "blocked_losses": 72,
      "missed_wins": 26,
      "blocked_net_R": -33.0
    }
  },
  "htf_short_vs_15m_long": {
    "input_trades_count": 85,
    "evaluated_trades_count": 85,
    "skipped_trades_count": 0,
    "skip_reasons": {},
    "wins": 22,
    "losses": 63,
    "open": 0,
    "winrate": 25.882352941176475,
    "profit_factor": 0.5238095238095238,
    "expectancy_R": -0.35294117647058826,
    "net_R": -30.0,
    "gross_win_R": 33.0,
    "gross_loss_R": 63.0,
    "max_drawdown_R": 31.5,
    "max_loss_streak": 22,
    "mae_summary": {
      "avg_MAE_R": -1.2301090245700088,
      "worst_MAE_R": -2.8249999999999917
    },
    "mfe_summary": {
      "avg_MFE_R": 0.7852042036633774,
      "best_MFE_R": 2.2957746478873364
    },
    "same_candle_conflicts": 0,
    "hypothesis_id": "htf_short_vs_15m_long",
    "mode": "rr_1_5",
    "allowed_trades": 85,
    "blocked_trades": 13,
    "blocked_losses": 9,
    "missed_wins": 4,
    "blocked_net_R": -3.0
  },
  "market_phase_unclear": {
    "input_trades_count": 92,
    "evaluated_trades_count": 92,
    "skipped_trades_count": 0,
    "skip_reasons": {},
    "wins": 23,
    "losses": 69,
    "open": 0,
    "winrate": 25.0,
    "profit_factor": 0.5,
    "expectancy_R": -0.375,
    "net_R": -34.5,
    "gross_win_R": 34.5,
    "gross_loss_R": 69.0,
    "max_drawdown_R": 36.0,
    "max_loss_streak": 24,
    "mae_summary": {
      "avg_MAE_R": -1.2340564503146094,
      "worst_MAE_R": -2.8249999999999917
    },
    "mfe_summary": {
      "avg_MFE_R": 0.793083053094954,
      "best_MFE_R": 2.2957746478873364
    },
    "same_candle_conflicts": 0,
    "hypothesis_id": "market_phase_unclear",
    "mode": "rr_1_5",
    "allowed_trades": 92,
    "blocked_trades": 6,
    "blocked_losses": 3,
    "missed_wins": 3,
    "blocked_net_R": 1.5
  },
  "setup_type": {
    "setup_unknown": {
      "input_trades_count": 27,
      "evaluated_trades_count": 27,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 6,
      "losses": 21,
      "open": 0,
      "winrate": 22.22222222222222,
      "profit_factor": 0.42857142857142855,
      "expectancy_R": -0.4444444444444444,
      "net_R": -12.0,
      "gross_win_R": 9.0,
      "gross_loss_R": 21.0,
      "max_drawdown_R": 12.0,
      "max_loss_streak": 11,
      "mae_summary": {
        "avg_MAE_R": -1.2597844623746663,
        "worst_MAE_R": -1.8817204301075185
      },
      "mfe_summary": {
        "avg_MFE_R": 0.814981387162769,
        "best_MFE_R": 2.0588235294117623
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "setup_unknown",
      "mode": "rr_1_5",
      "allowed_trades": 27,
      "blocked_trades": 71,
      "blocked_losses": 51,
      "missed_wins": 20,
      "blocked_net_R": -21.0
    },
    "setup_rebound": {
      "input_trades_count": 67,
      "evaluated_trades_count": 67,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 16,
      "losses": 51,
      "open": 0,
      "winrate": 23.88059701492537,
      "profit_factor": 0.47058823529411764,
      "expectancy_R": -0.40298507462686567,
      "net_R": -27.0,
      "gross_win_R": 24.0,
      "gross_loss_R": 51.0,
      "max_drawdown_R": 28.5,
      "max_loss_streak": 17,
      "mae_summary": {
        "avg_MAE_R": -1.2248077112957465,
        "worst_MAE_R": -2.8249999999999917
      },
      "mfe_summary": {
        "avg_MFE_R": 0.7547759344468974,
        "best_MFE_R": 2.2957746478873364
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "setup_rebound",
      "mode": "rr_1_5",
      "allowed_trades": 67,
      "blocked_trades": 31,
      "blocked_losses": 21,
      "missed_wins": 10,
      "blocked_net_R": -6.0
    },
    "setup_continuation": {
      "input_trades_count": 4,
      "evaluated_trades_count": 4,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 4,
      "losses": 0,
      "open": 0,
      "winrate": 100.0,
      "profit_factor": 6.0,
      "expectancy_R": 1.5,
      "net_R": 6.0,
      "gross_win_R": 6.0,
      "gross_loss_R": 0,
      "max_drawdown_R": 0.0,
      "max_loss_streak": 0,
      "mae_summary": {
        "avg_MAE_R": -0.726532701322356,
        "worst_MAE_R": -0.7982456140350902
      },
      "mfe_summary": {
        "avg_MFE_R": 1.5903995226847065,
        "best_MFE_R": 1.6578947368421075
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "setup_continuation",
      "mode": "rr_1_5",
      "allowed_trades": 4,
      "blocked_trades": 94,
      "blocked_losses": 72,
      "missed_wins": 22,
      "blocked_net_R": -39.0
    }
  },
  "session": {
    "session_asia": {
      "input_trades_count": 14,
      "evaluated_trades_count": 14,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 4,
      "losses": 10,
      "open": 0,
      "winrate": 28.57142857142857,
      "profit_factor": 0.6,
      "expectancy_R": -0.2857142857142857,
      "net_R": -4.0,
      "gross_win_R": 6.0,
      "gross_loss_R": 10.0,
      "max_drawdown_R": 9.0,
      "max_loss_streak": 9,
      "mae_summary": {
        "avg_MAE_R": -1.2035377697067882,
        "worst_MAE_R": -2.8249999999999917
      },
      "mfe_summary": {
        "avg_MFE_R": 1.0757925179571182,
        "best_MFE_R": 1.9999999999999885
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "session_asia",
      "mode": "rr_1_5",
      "allowed_trades": 14,
      "blocked_trades": 84,
      "blocked_losses": 62,
      "missed_wins": 22,
      "blocked_net_R": -29.0
    },
    "session_europe": {
      "input_trades_count": 0,
      "evaluated_trades_count": 0,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 0,
      "losses": 0,
      "open": 0,
      "winrate": 0.0,
      "profit_factor": 0.0,
      "expectancy_R": 0.0,
      "net_R": 0,
      "gross_win_R": 0,
      "gross_loss_R": 0,
      "max_drawdown_R": 0.0,
      "max_loss_streak": 0,
      "mae_summary": {
        "avg_MAE_R": 0.0,
        "worst_MAE_R": 0.0
      },
      "mfe_summary": {
        "avg_MFE_R": 0.0,
        "best_MFE_R": 0.0
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "session_europe",
      "mode": "rr_1_5",
      "allowed_trades": 0,
      "blocked_trades": 98,
      "blocked_losses": 72,
      "missed_wins": 26,
      "blocked_net_R": -33.0
    },
    "session_us": {
      "input_trades_count": 51,
      "evaluated_trades_count": 51,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 19,
      "losses": 32,
      "open": 0,
      "winrate": 37.254901960784316,
      "profit_factor": 0.890625,
      "expectancy_R": -0.06862745098039216,
      "net_R": -3.5,
      "gross_win_R": 28.5,
      "gross_loss_R": 32.0,
      "max_drawdown_R": 15.0,
      "max_loss_streak": 15,
      "mae_summary": {
        "avg_MAE_R": -1.0907759884300452,
        "worst_MAE_R": -2.231884057971015
      },
      "mfe_summary": {
        "avg_MFE_R": 0.90218215966549,
        "best_MFE_R": 2.2957746478873364
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "session_us",
      "mode": "rr_1_5",
      "allowed_trades": 51,
      "blocked_trades": 47,
      "blocked_losses": 40,
      "missed_wins": 7,
      "blocked_net_R": -29.5
    },
    "session_overlap": {
      "input_trades_count": 20,
      "evaluated_trades_count": 20,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 2,
      "losses": 18,
      "open": 0,
      "winrate": 10.0,
      "profit_factor": 0.16666666666666666,
      "expectancy_R": -0.75,
      "net_R": -15.0,
      "gross_win_R": 3.0,
      "gross_loss_R": 18.0,
      "max_drawdown_R": 16.5,
      "max_loss_streak": 10,
      "mae_summary": {
        "avg_MAE_R": -1.491913432199415,
        "worst_MAE_R": -2.6190476190476275
      },
      "mfe_summary": {
        "avg_MFE_R": 0.4647723817455211,
        "best_MFE_R": 1.6666666666666339
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "session_overlap",
      "mode": "rr_1_5",
      "allowed_trades": 20,
      "blocked_trades": 78,
      "blocked_losses": 54,
      "missed_wins": 24,
      "blocked_net_R": -18.0
    }
  },
  "time_after_14_msk": {
    "input_trades_count": 71,
    "evaluated_trades_count": 71,
    "skipped_trades_count": 0,
    "skip_reasons": {},
    "wins": 21,
    "losses": 50,
    "open": 0,
    "winrate": 29.577464788732392,
    "profit_factor": 0.63,
    "expectancy_R": -0.2605633802816901,
    "net_R": -18.5,
    "gross_win_R": 31.5,
    "gross_loss_R": 50.0,
    "max_drawdown_R": 23.0,
    "max_loss_streak": 15,
    "mae_summary": {
      "avg_MAE_R": -1.2037724514636707,
      "worst_MAE_R": -2.6190476190476275
    },
    "mfe_summary": {
      "avg_MFE_R": 0.7789681377162029,
      "best_MFE_R": 2.2957746478873364
    },
    "same_candle_conflicts": 0,
    "hypothesis_id": "time_after_14_msk",
    "mode": "rr_1_5",
    "allowed_trades": 71,
    "blocked_trades": 27,
    "blocked_losses": 22,
    "missed_wins": 5,
    "blocked_net_R": -14.5
  },
  "clusters": {
    "unclear + Europe + rebound": {
      "input_trades_count": 0,
      "evaluated_trades_count": 0,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 0,
      "losses": 0,
      "open": 0,
      "winrate": 0.0,
      "profit_factor": 0.0,
      "expectancy_R": 0.0,
      "net_R": 0,
      "gross_win_R": 0,
      "gross_loss_R": 0,
      "max_drawdown_R": 0.0,
      "max_loss_streak": 0,
      "mae_summary": {
        "avg_MAE_R": 0.0,
        "worst_MAE_R": 0.0
      },
      "mfe_summary": {
        "avg_MFE_R": 0.0,
        "best_MFE_R": 0.0
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "cluster_unclear_europe_rebound",
      "mode": "rr_1_5",
      "allowed_trades": 0,
      "blocked_trades": 98,
      "blocked_losses": 72,
      "missed_wins": 26,
      "blocked_net_R": -33.0
    },
    "unclear + HTF Short + unknown": {
      "input_trades_count": 18,
      "evaluated_trades_count": 18,
      "skipped_trades_count": 0,
      "skip_reasons": {},
      "wins": 5,
      "losses": 13,
      "open": 0,
      "winrate": 27.77777777777778,
      "profit_factor": 0.5769230769230769,
      "expectancy_R": -0.3055555555555556,
      "net_R": -5.5,
      "gross_win_R": 7.5,
      "gross_loss_R": 13.0,
      "max_drawdown_R": 8.0,
      "max_loss_streak": 8,
      "mae_summary": {
        "avg_MAE_R": -1.298329402459205,
        "worst_MAE_R": -1.8817204301075185
      },
      "mfe_summary": {
        "avg_MFE_R": 0.8143769802262277,
        "best_MFE_R": 2.0588235294117623
      },
      "same_candle_conflicts": 0,
      "hypothesis_id": "cluster_unclear_htf_short_unknown",
      "mode": "rr_1_5",
      "allowed_trades": 18,
      "blocked_trades": 80,
      "blocked_losses": 59,
      "missed_wins": 21,
      "blocked_net_R": -27.5
    }
  }
}
```

## Safety

- No production decision is made by this report.
- No live paper, real orders, or testnet orders were started.