# Candidate Source Audit

## 1. Executive Summary

Status: `READY`

Current live paper candidate source is `simplified_placeholder`.

The sandbox currently creates live signal candidates in `src/signal_adapter.py::signal_from_klines()`. `src/live_research_engine.py` calls this function after fetching Binance Futures public klines and filtering to the latest closed `15m` candle.

This is sufficient for technical live paper lifecycle checks: open virtual positions, close by TP/SL, persist state, update runtime status, and verify Telegram-facing status flow.

It is not sufficient for edge conclusions. The current live candidate builder is a simple MA/ATR placeholder. It does not reproduce production entry logic, does not build a reliable market/session/setup context, and does not provide several fields used by old-sample hypotheses.

Task 5C-B should not add a new strategy yet. The next safe implementation step is to introduce an explicit candidate source boundary/adapter with source metadata and validation, while keeping `simplified_placeholder` as a technical smoke source only.

## 2. Current Candidate Flow

Current live flow:

```text
src.main live-research
  -> LiveResearchEngine.run()
  -> get_latest_klines(symbol, 15m, public Binance REST)
  -> _latest_closed_klines()
  -> dedupe by symbol:timeframe close_time
  -> update existing virtual positions by PaperBroker.update_positions()
  -> signal_adapter.signal_from_klines()
  -> if direction != LONG: ignore and count
  -> HypothesisRunner.process_signal()
  -> PaperBroker.open_position()
```

Current journal/replay flow:

```text
src.main paper-demo / replay-style paths
  -> signal_adapter.signals_from_journal()
  -> journal_loader.load_journal_csv()
  -> SignalCandidate(...)
  -> HypothesisRunner.run_replay()
```

## 3. Files Inspected

- `reports/LIVE_PAPER_READINESS_AUDIT.md`
- `reports/PROJECT_PLAN_MAP.md`
- `reports/LIVE_PAPER_LIFECYCLE_MVP_REPORT.md`
- `reports/LIVE_PAPER_LIFECYCLE_MVP_REPORT.json`
- `src/main.py`
- `src/live_research_engine.py`
- `src/signal_adapter.py`
- `src/order_models.py`
- `src/market_context.py`
- `src/session_classifier.py`
- `src/trend_context_analyzer.py`
- `src/hypothesis_runner.py`
- `src/hypothesis_registry.py`
- `src/paper_broker.py`
- `src/runtime_status.py`
- `src/binance_data.py`
- `config/research_config.yaml`
- `config/hypotheses.yaml`
- `tests/test_signal_adapter.py`
- `tests/test_live_paper_lifecycle.py`

## 4. Current Candidate Builder Location

Live candidate builder:

```text
src/signal_adapter.py::signal_from_klines(symbol, timeframe, klines)
```

Live caller:

```text
src/live_research_engine.py::LiveResearchEngine.run()
```

Journal candidate adapter:

```text
src/signal_adapter.py::signals_from_journal(file_path, timeframe)
```

Candidate model:

```text
src/order_models.py::SignalCandidate
```

## 5. Current Candidate Fields

The typed candidate model supports:

- `symbol`
- `timeframe`
- `direction`
- `entry`
- `tp`
- `sl`
- `rr_ratio`
- `created_at`
- `rsi`
- `atr_pct`
- `market_phase`
- `session`
- `setup_type`
- `trend_htf`
- `reason`
- `confidence_factors`
- `signal_source`
- `source`
- `result`
- `historical_r`
- `raw`

Live `signal_from_klines()` currently fills:

- `symbol`: uppercased input symbol
- `timeframe`: CLI/config timeframe
- `direction`: `LONG` if MA fast >= MA slow, else `SHORT`
- `entry`: latest closed candle close
- `tp`: ATR/risk-distance based 1.5R target
- `sl`: ATR/risk-distance based stop
- `rr_ratio`: `1.5`
- `created_at`: current UTC timestamp
- `rsi`: simple RSI from close series
- `atr_pct`: ATR divided by last close
- `market_phase`: `trend` or `unclear` from MA distance
- `session`: hardcoded `LIVE`
- `setup_type`: `continuation` or `rebound` from MA distance
- `trend_htf`: `aligned` or `countertrend` from the same MA relation
- `reason`: `simplified_ma_atr_signal`
- `signal_source`: `research_simplified_live`
- `source`: `binance_public_rest`
- `raw`: latest kline row

Journal `signals_from_journal()` can preserve richer old production fields when CSV columns exist.

## 6. Missing / Weak Fields

Missing or weak in current live placeholder:

- `session`: hardcoded `LIVE`, not `ASIA/EUROPE/US/OVERLAP`.
- `hour_msk`: not added to `raw`, so time-bucket hypotheses cannot work reliably.
- `trend_htf`: live value is `aligned/countertrend`, while historical HTF logic often expects `Long/Short`, `bullish/bearish`, or normalized HTF direction.
- `market_phase`: simplified from MA distance, not production-like market context.
- `setup_type`: simplified from MA distance, not production-like setup classification.
- `market_mode`: absent from live `raw`.
- `score`: absent from live `raw`.
- `confidence_factors`: absent in live placeholder.
- `impulse_before_entry`: absent in live placeholder.
- `reason`: present, but only says `simplified_ma_atr_signal`.
- `entry model metadata`: no explicit adapter version/schema beyond `signal_source`.

Fields needed by default hypotheses:

- `rsi`
- `session`
- `market_phase`
- `setup_type`

Fields needed by Research Pack 2 style hypotheses, if ever enabled later:

- `trend_htf`
- `hour_msk`
- `market_mode`
- `score`
- `atr_pct`

Research Pack 2 remains disabled for live runtime.

## 7. LONG-only Status

`signal_from_klines()` can generate both `LONG` and `SHORT`.

The LONG-only restriction from Task 5B is applied in:

```text
src/live_research_engine.py::LiveResearchEngine.run()
```

Current logic:

```text
if signal.direction.upper() != "LONG":
    ignored_short_candidates_count += 1
else:
    runner.process_signal(signal, close_from_history=False)
```

This means SHORT candidates are built by the placeholder, but they are not opened in live paper MVP.

## 8. SHORT Handling Status

Status: `PARTIAL / SAFE FOR MVP`

SHORT candidates are safely ignored before hypothesis processing and before paper broker open. The runtime status counts them in `ignored_short_candidates_count`.

Limitation: the builder still creates SHORT candidates internally. For a cleaner Task 5C-B boundary, the adapter should explicitly declare whether it emits `LONG_ONLY` or `LONG_AND_SHORT`, and live MVP should keep rejecting unsupported directions.

## 9. Placeholder vs Production-like Assessment

Current live source is not production-like.

Reason:

- Uses simple MA fast/slow direction.
- Uses ATR-derived TP/SL.
- Assigns session as `LIVE`.
- Assigns market phase and setup type from MA distance only.
- Does not reproduce production signal flow.
- Does not include reliable old-journal context fields like `hour_msk`, `market_mode`, `score`, or production-style HTF direction.

It should be labelled as:

```text
simplified_placeholder
```

## 10. Can Current Builder Be Used For Technical Live Paper?

Yes.

It can be used to verify:

- Binance public candle polling.
- Closed `15m` candle dedupe.
- Virtual open flow.
- Virtual TP/SL close flow.
- Open position persistence.
- Closed trade persistence.
- Runtime status updates.
- Telegram-facing status file compatibility.
- Safety guard behavior.

It is adequate for lifecycle smoke testing.

## 11. Can Current Builder Be Used For Edge Conclusions?

No.

It should not be used to conclude that a trading edge exists or does not exist.

Reason:

- It is not production baseline logic.
- It is not a validated new entry model.
- Its context labels are synthetic and weak.
- Many hypothesis fields are absent or unreliable.
- A live paper result from this source would measure the placeholder, not Crypto13 production logic and not a real candidate model.

## 12. Candidate Source Options

### simplified_placeholder

Current state.

Purpose:

- Technical live paper lifecycle verification.
- Status/report/Telegram smoke testing.
- No edge conclusions.

Current implementation:

- `src/signal_adapter.py::signal_from_klines()`
- Source metadata: `signal_source=research_simplified_live`, `source=binance_public_rest`

Required guard:

- Keep explicit `candidate_mode=simplified_or_existing` or rename to `simplified_placeholder`.
- Keep warning in reports/status that this source is not for edge conclusions.

### production_baseline_export

Future option.

Purpose:

- Import production-like or old production candidate exports as baseline/reference.
- Compare sandbox hypotheses against the current/old production candidate stream.
- Avoid changing production.

Important boundary:

- Production logic is reference only.
- Sandbox must not depend on production as its final future strategy.
- No production DB writes and no production process control.

Likely input:

- CSV/JSONL export with `symbol`, `timeframe`, `direction`, `entry`, `tp`, `sl`, `created_at`, `session`, `market_phase`, `setup_type`, `trend_htf`, `rsi`, `atr_pct`, `reason`, optional `score`, `market_mode`, `confidence_factors`.

### new_entry_model_adapter

Future primary research path.

Purpose:

- Build a sandbox-native entry layer that can test new entry logic without touching production.
- Generate candidates with explicit schema/version/source metadata.
- Support fair live paper evaluation and later human-reviewed production decisions.

Required boundary:

- This is a new research layer, not an automatic production filter.
- Must be added as a separate adapter, not mixed into the lifecycle code.

## 13. Recommended Next Implementation Task: Task 5C-B

Recommended next task:

```text
Task 5C-B — Candidate Source Boundary / Adapter Interface
```

Goal:

Create a small explicit boundary around candidate creation without changing trading logic.

## 14. Exact Recommended Scope For Task 5C-B

Task 5C-B should implement only:

1. Add a candidate source enum/metadata contract:
   - `simplified_placeholder`
   - `production_baseline_export`
   - `new_entry_model_adapter`
2. Add adapter result metadata:
   - `candidate_source`
   - `candidate_source_version`
   - `is_placeholder`
   - `edge_conclusions_allowed`
   - `direction_support`
3. Rename or wrap current `signal_from_klines()` as the `simplified_placeholder` adapter.
4. Keep the same MA/ATR placeholder logic for now.
5. Add validation that live MVP accepts only `15m` and `LONG`.
6. Add explicit warning in runtime status/report when placeholder source is used.
7. Add a stub/interface for future `production_baseline_export`.
8. Add a stub/interface for future `new_entry_model_adapter`.
9. Add tests for source metadata and SHORT rejection.

Task 5C-B should not:

- implement a new strategy;
- import production code;
- connect to production;
- add private API;
- change RR/TP/SL/risk/leverage;
- enable Research Pack 2 live;
- deploy;
- change Telegram dashboard scope.

## 15. Risks

1. Placeholder context can make hypotheses appear good or bad for the wrong reason.
2. `session=LIVE` means session-based hypotheses do not behave like old-sample research.
3. `trend_htf=aligned/countertrend` is not compatible with HTF Short/Bullish/Bearish semantics without normalization.
4. `hour_msk`, `score`, and `market_mode` are absent, so several Research Pack 2 hypotheses would be invalid in live mode.
5. If reports do not label the source clearly, future results could be mistaken for edge evidence.
6. The current builder can emit SHORT; live engine blocks it safely, but the source boundary should declare direction support explicitly.

## 16. Safety Confirmations

- Sandbox only: `true`
- Production Crypto13 touched: `false`
- Private Binance API used: `false`
- Real orders added: `false`
- Testnet orders added: `false`
- Deploy changed: `false`
- Telegram dashboard changed: `false`
- New hypotheses added: `false`
- Research Pack 2 live enabled: `false`
- Runtime code changed: `false`

## Tests

Tests were not run because this was audit/report-only and runtime code was not changed.

