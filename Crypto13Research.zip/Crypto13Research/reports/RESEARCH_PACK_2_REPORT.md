# Research Pack 2 Report

**Status:** READY

- hypotheses added: 54
- hypotheses skipped: 3 (already present)
- total hypotheses: 69
- evaluated/skipped trades: 98/0
- ATR q33/q66: 0.0059418877 / 0.0077142038
- warning: research-only; no production decision.

## Hypotheses Added

ban_unknown_setup, allow_only_rebound, allow_only_unknown, ban_rebound, ban_rebound_without_htf_support, allow_rebound_only_if_htf_not_short, allow_rebound_only_if_rsi_mid, allow_continuation_only_rsi_40_65, allow_long_only_if_htf_not_short, ban_htf_short_for_15m_long, allow_countertrend_only_in_us_session, allow_countertrend_only_if_rsi_mid, ban_europe, allow_only_us, allow_us_and_asia_only, ban_europe_rebound, ban_overlap_rebound, ban_europe_unknown, ban_overlap_unknown, allow_us_continuation_only, allow_us_mid_rsi_only, hour_10_14_msk, hour_14_17_msk, hour_17_20_msk, hour_20_23_msk, ban_hours_before_14_msk, allow_15_20_msk, allow_17_20_msk, allow_rsi_40_55, allow_rsi_45_60, allow_rsi_40_65, ban_rsi_below_45, ban_rsi_above_60, ban_rsi_above_65, atr_low_bucket, atr_mid_bucket, atr_high_bucket, ban_low_atr, ban_high_atr, allow_mid_atr_only, low_atr_rebound_toxic, low_atr_unknown_toxic, high_atr_rebound_toxic, market_mode_pullback_impulse, market_mode_extreme_reversion, ban_pullback_impulse_if_htf_short, allow_pullback_impulse_only_us, ban_extreme_reversion, score_70_80, score_80_90, score_90_plus, allow_score_80_plus, allow_score_90_plus, ban_score_below_80

## Hypotheses Skipped

- allow_only_continuation: already present
- ban_overlap: already present
- ban_rsi_below_40: already present

## Leaderboard By Expectancy R

| hypothesis | trades | winrate | PF | expectancy_R | net_R | <20 warning |
| --- | --- | --- | --- | --- | --- | --- |
| allow_only_continuation | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_continuation_only_rsi_40_65 | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_us_continuation_only | 2 | 100.00% | 3.0000 | 1.5000 | 3.00 | YES |
| allow_rebound_only_if_htf_not_short | 6 | 50.00% | 1.5000 | 0.2500 | 1.50 | YES |
| hour_20_23_msk | 4 | 50.00% | 1.5000 | 0.2500 | 1.00 | YES |
| allow_us_mid_rsi_only | 23 | 47.83% | 1.3750 | 0.1957 | 4.50 |  |
| score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |
| allow_score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |
| allow_pullback_impulse_only_us | 45 | 37.78% | 0.9107 | -0.0556 | -2.50 |  |
| allow_countertrend_only_in_us_session | 59 | 37.29% | 0.8919 | -0.0678 | -4.00 |  |
| allow_only_us | 51 | 37.25% | 0.8906 | -0.0686 | -3.50 |  |
| allow_rebound_only_if_rsi_mid | 19 | 36.84% | 0.8750 | -0.0789 | -1.50 | YES |
| allow_us_and_asia_only | 65 | 35.38% | 0.8214 | -0.1154 | -7.50 |  |
| allow_countertrend_only_if_rsi_mid | 51 | 35.29% | 0.8182 | -0.1176 | -6.00 |  |
| ban_rebound_without_htf_support | 37 | 35.14% | 0.8125 | -0.1216 | -4.50 |  |
| hour_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| allow_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| allow_us_unknown | 49 | 34.69% | 0.7969 | -0.1327 | -6.50 |  |
| ban_rsi_below_40 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| ban_unclear_low_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_only_mid_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_55 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_65 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_score_80_plus | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| ban_score_below_80 | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| allow_rsi_45_60 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| ban_rsi_below_45 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| ban_rsi_below_35 | 71 | 32.39% | 0.7188 | -0.1901 | -13.50 |  |
| ban_rebound | 31 | 32.26% | 0.7143 | -0.1935 | -6.00 |  |
| ban_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| ban_unclear_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| allow_long_only_if_htf_not_short | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| ban_htf_short_for_15m_long | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| atr_high_bucket | 33 | 30.30% | 0.6522 | -0.2424 | -8.00 |  |
| ban_rsi_below_38 | 60 | 30.00% | 0.6429 | -0.2500 | -15.00 |  |
| market_mode_pullback_impulse | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_extreme_reversion | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_hours_before_14_msk | 71 | 29.58% | 0.6300 | -0.2606 | -18.50 |  |
| ban_unclear_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_rebound_europe | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_unclear_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_low_atr | 65 | 29.23% | 0.6196 | -0.2692 | -17.50 |  |
| ban_low_rsi_europe | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_europe_low_rsi | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_overlap_unknown | 90 | 28.89% | 0.6094 | -0.2778 | -25.00 |  |
| score_80_90 | 42 | 28.57% | 0.6000 | -0.2857 | -12.00 |  |
| low_atr_rebound_toxic | 74 | 28.38% | 0.5943 | -0.2905 | -21.50 |  |
| ban_unknown_setup | 71 | 28.17% | 0.5882 | -0.2958 | -21.00 |  |
| atr_mid_bucket | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| allow_mid_atr_only | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| ban_overlap_rebound | 86 | 27.91% | 0.5806 | -0.3023 | -26.00 |  |
| low_atr_unknown_toxic | 90 | 27.78% | 0.5769 | -0.3056 | -27.50 |  |
| ban_europe_unknown | 96 | 27.08% | 0.5571 | -0.3229 | -31.00 |  |
| high_atr_rebound_toxic | 78 | 26.92% | 0.5526 | -0.3269 | -25.50 |  |
| allow_15_20_msk | 64 | 26.56% | 0.5426 | -0.3359 | -21.50 |  |
| baseline_rr15 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_rsi_above_60 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_rsi_above_65 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_high_atr | 65 | 24.62% | 0.4898 | -0.3846 | -25.00 |  |
| allow_only_rebound | 67 | 23.88% | 0.4706 | -0.4030 | -27.00 |  |
| allow_only_unknown | 27 | 22.22% | 0.4286 | -0.4444 | -12.00 |  |
| atr_low_bucket | 33 | 21.21% | 0.4038 | -0.4697 | -15.50 |  |
| ban_pullback_impulse_if_htf_short | 30 | 20.00% | 0.3750 | -0.5000 | -15.00 |  |
| market_mode_extreme_reversion | 17 | 11.76% | 0.2000 | -0.7059 | -12.00 | YES |
| score_70_80 | 29 | 10.34% | 0.1731 | -0.7414 | -21.50 |  |
| hour_14_17_msk | 20 | 10.00% | 0.1667 | -0.7500 | -15.00 |  |
| hour_10_14_msk | 13 | 7.69% | 0.1250 | -0.8077 | -10.50 | YES |

## Leaderboard By Profit Factor

| hypothesis | trades | winrate | PF | expectancy_R | net_R | <20 warning |
| --- | --- | --- | --- | --- | --- | --- |
| allow_only_continuation | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_continuation_only_rsi_40_65 | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_us_continuation_only | 2 | 100.00% | 3.0000 | 1.5000 | 3.00 | YES |
| allow_rebound_only_if_htf_not_short | 6 | 50.00% | 1.5000 | 0.2500 | 1.50 | YES |
| hour_20_23_msk | 4 | 50.00% | 1.5000 | 0.2500 | 1.00 | YES |
| allow_us_mid_rsi_only | 23 | 47.83% | 1.3750 | 0.1957 | 4.50 |  |
| score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |
| allow_score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |
| allow_pullback_impulse_only_us | 45 | 37.78% | 0.9107 | -0.0556 | -2.50 |  |
| allow_countertrend_only_in_us_session | 59 | 37.29% | 0.8919 | -0.0678 | -4.00 |  |
| allow_only_us | 51 | 37.25% | 0.8906 | -0.0686 | -3.50 |  |
| allow_rebound_only_if_rsi_mid | 19 | 36.84% | 0.8750 | -0.0789 | -1.50 | YES |
| allow_us_and_asia_only | 65 | 35.38% | 0.8214 | -0.1154 | -7.50 |  |
| allow_countertrend_only_if_rsi_mid | 51 | 35.29% | 0.8182 | -0.1176 | -6.00 |  |
| ban_rebound_without_htf_support | 37 | 35.14% | 0.8125 | -0.1216 | -4.50 |  |
| hour_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| allow_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| allow_us_unknown | 49 | 34.69% | 0.7969 | -0.1327 | -6.50 |  |
| ban_rsi_below_40 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| ban_unclear_low_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_only_mid_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_55 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_65 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_score_80_plus | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| ban_score_below_80 | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| allow_rsi_45_60 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| ban_rsi_below_45 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| ban_rsi_below_35 | 71 | 32.39% | 0.7188 | -0.1901 | -13.50 |  |
| ban_rebound | 31 | 32.26% | 0.7143 | -0.1935 | -6.00 |  |
| ban_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| ban_unclear_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| allow_long_only_if_htf_not_short | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| ban_htf_short_for_15m_long | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| atr_high_bucket | 33 | 30.30% | 0.6522 | -0.2424 | -8.00 |  |
| ban_rsi_below_38 | 60 | 30.00% | 0.6429 | -0.2500 | -15.00 |  |
| market_mode_pullback_impulse | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_extreme_reversion | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_hours_before_14_msk | 71 | 29.58% | 0.6300 | -0.2606 | -18.50 |  |
| ban_unclear_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_rebound_europe | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_unclear_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_low_atr | 65 | 29.23% | 0.6196 | -0.2692 | -17.50 |  |
| ban_low_rsi_europe | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_europe_low_rsi | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_overlap_unknown | 90 | 28.89% | 0.6094 | -0.2778 | -25.00 |  |
| score_80_90 | 42 | 28.57% | 0.6000 | -0.2857 | -12.00 |  |
| low_atr_rebound_toxic | 74 | 28.38% | 0.5943 | -0.2905 | -21.50 |  |
| ban_unknown_setup | 71 | 28.17% | 0.5882 | -0.2958 | -21.00 |  |
| atr_mid_bucket | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| allow_mid_atr_only | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| ban_overlap_rebound | 86 | 27.91% | 0.5806 | -0.3023 | -26.00 |  |
| low_atr_unknown_toxic | 90 | 27.78% | 0.5769 | -0.3056 | -27.50 |  |
| ban_europe_unknown | 96 | 27.08% | 0.5571 | -0.3229 | -31.00 |  |
| high_atr_rebound_toxic | 78 | 26.92% | 0.5526 | -0.3269 | -25.50 |  |
| allow_15_20_msk | 64 | 26.56% | 0.5426 | -0.3359 | -21.50 |  |
| baseline_rr15 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_rsi_above_60 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_rsi_above_65 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_high_atr | 65 | 24.62% | 0.4898 | -0.3846 | -25.00 |  |
| allow_only_rebound | 67 | 23.88% | 0.4706 | -0.4030 | -27.00 |  |
| allow_only_unknown | 27 | 22.22% | 0.4286 | -0.4444 | -12.00 |  |
| atr_low_bucket | 33 | 21.21% | 0.4038 | -0.4697 | -15.50 |  |
| ban_pullback_impulse_if_htf_short | 30 | 20.00% | 0.3750 | -0.5000 | -15.00 |  |
| market_mode_extreme_reversion | 17 | 11.76% | 0.2000 | -0.7059 | -12.00 | YES |
| score_70_80 | 29 | 10.34% | 0.1731 | -0.7414 | -21.50 |  |
| hour_14_17_msk | 20 | 10.00% | 0.1667 | -0.7500 | -15.00 |  |
| hour_10_14_msk | 13 | 7.69% | 0.1250 | -0.8077 | -10.50 | YES |

## Leaderboard By Net R

| hypothesis | trades | winrate | PF | expectancy_R | net_R | <20 warning |
| --- | --- | --- | --- | --- | --- | --- |
| allow_only_continuation | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_continuation_only_rsi_40_65 | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_us_mid_rsi_only | 23 | 47.83% | 1.3750 | 0.1957 | 4.50 |  |
| allow_us_continuation_only | 2 | 100.00% | 3.0000 | 1.5000 | 3.00 | YES |
| allow_rebound_only_if_htf_not_short | 6 | 50.00% | 1.5000 | 0.2500 | 1.50 | YES |
| hour_20_23_msk | 4 | 50.00% | 1.5000 | 0.2500 | 1.00 | YES |
| score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |
| allow_score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |
| allow_rebound_only_if_rsi_mid | 19 | 36.84% | 0.8750 | -0.0789 | -1.50 | YES |
| allow_pullback_impulse_only_us | 45 | 37.78% | 0.9107 | -0.0556 | -2.50 |  |
| allow_long_only_if_htf_not_short | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| ban_htf_short_for_15m_long | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| allow_only_us | 51 | 37.25% | 0.8906 | -0.0686 | -3.50 |  |
| allow_countertrend_only_in_us_session | 59 | 37.29% | 0.8919 | -0.0678 | -4.00 |  |
| ban_rebound_without_htf_support | 37 | 35.14% | 0.8125 | -0.1216 | -4.50 |  |
| allow_rsi_45_60 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| ban_rsi_below_45 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| allow_countertrend_only_if_rsi_mid | 51 | 35.29% | 0.8182 | -0.1176 | -6.00 |  |
| hour_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| allow_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| ban_rebound | 31 | 32.26% | 0.7143 | -0.1935 | -6.00 |  |
| allow_us_unknown | 49 | 34.69% | 0.7969 | -0.1327 | -6.50 |  |
| allow_us_and_asia_only | 65 | 35.38% | 0.8214 | -0.1154 | -7.50 |  |
| ban_rsi_below_40 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| ban_unclear_low_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_only_mid_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_55 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_65 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| atr_high_bucket | 33 | 30.30% | 0.6522 | -0.2424 | -8.00 |  |
| atr_mid_bucket | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| allow_mid_atr_only | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| hour_10_14_msk | 13 | 7.69% | 0.1250 | -0.8077 | -10.50 | YES |
| allow_score_80_plus | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| ban_score_below_80 | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| score_80_90 | 42 | 28.57% | 0.6000 | -0.2857 | -12.00 |  |
| allow_only_unknown | 27 | 22.22% | 0.4286 | -0.4444 | -12.00 |  |
| market_mode_extreme_reversion | 17 | 11.76% | 0.2000 | -0.7059 | -12.00 | YES |
| ban_rsi_below_35 | 71 | 32.39% | 0.7188 | -0.1901 | -13.50 |  |
| ban_rsi_below_38 | 60 | 30.00% | 0.6429 | -0.2500 | -15.00 |  |
| ban_pullback_impulse_if_htf_short | 30 | 20.00% | 0.3750 | -0.5000 | -15.00 |  |
| hour_14_17_msk | 20 | 10.00% | 0.1667 | -0.7500 | -15.00 |  |
| atr_low_bucket | 33 | 21.21% | 0.4038 | -0.4697 | -15.50 |  |
| ban_low_atr | 65 | 29.23% | 0.6196 | -0.2692 | -17.50 |  |
| ban_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| ban_unclear_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| ban_hours_before_14_msk | 71 | 29.58% | 0.6300 | -0.2606 | -18.50 |  |
| market_mode_pullback_impulse | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_extreme_reversion | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_unknown_setup | 71 | 28.17% | 0.5882 | -0.2958 | -21.00 |  |
| low_atr_rebound_toxic | 74 | 28.38% | 0.5943 | -0.2905 | -21.50 |  |
| allow_15_20_msk | 64 | 26.56% | 0.5426 | -0.3359 | -21.50 |  |
| score_70_80 | 29 | 10.34% | 0.1731 | -0.7414 | -21.50 |  |
| ban_unclear_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_unclear_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_rebound_europe | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_low_rsi_europe | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_europe_low_rsi | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_overlap_unknown | 90 | 28.89% | 0.6094 | -0.2778 | -25.00 |  |
| ban_high_atr | 65 | 24.62% | 0.4898 | -0.3846 | -25.00 |  |
| high_atr_rebound_toxic | 78 | 26.92% | 0.5526 | -0.3269 | -25.50 |  |
| ban_overlap_rebound | 86 | 27.91% | 0.5806 | -0.3023 | -26.00 |  |
| allow_only_rebound | 67 | 23.88% | 0.4706 | -0.4030 | -27.00 |  |
| low_atr_unknown_toxic | 90 | 27.78% | 0.5769 | -0.3056 | -27.50 |  |
| ban_europe_unknown | 96 | 27.08% | 0.5571 | -0.3229 | -31.00 |  |
| baseline_rr15 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_rsi_above_60 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |
| ban_rsi_above_65 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |

## Duplicate / Equivalent Masks

| hypotheses | matching rows | blocked rows |
| --- | --- | --- |
| baseline_rr15 = ban_rsi_above_60 = ban_rsi_above_65 | 98 | 0 |
| ban_rsi_below_40 = ban_unclear_low_rsi = allow_only_mid_rsi = allow_rsi_40_55 = allow_rsi_40_65 | 50 | 48 |
| ban_unclear_europe_rebound = ban_rebound_europe = ban_europe_rebound | 88 | 10 |
| ban_overlap = ban_unclear_overlap | 78 | 20 |
| ban_low_rsi_europe = ban_europe_low_rsi | 89 | 9 |
| ban_unclear_europe = ban_europe | 85 | 13 |
| allow_only_continuation = allow_continuation_only_rsi_40_65 | 4 | 94 |
| allow_long_only_if_htf_not_short = ban_htf_short_for_15m_long | 13 | 85 |
| hour_17_20_msk = allow_17_20_msk | 46 | 52 |
| allow_rsi_45_60 = ban_rsi_below_45 | 30 | 68 |
| atr_mid_bucket = allow_mid_atr_only | 32 | 66 |
| market_mode_pullback_impulse = ban_extreme_reversion | 81 | 17 |
| score_90_plus = allow_score_90_plus | 27 | 71 |
| allow_score_80_plus = ban_score_below_80 | 69 | 29 |

## Top 10 Toxic Filters

| hypothesis | trades | winrate | PF | expectancy_R | net_R | <20 warning |
| --- | --- | --- | --- | --- | --- | --- |
| hour_10_14_msk | 13 | 7.69% | 0.1250 | -0.8077 | -10.50 | YES |
| hour_14_17_msk | 20 | 10.00% | 0.1667 | -0.7500 | -15.00 |  |
| score_70_80 | 29 | 10.34% | 0.1731 | -0.7414 | -21.50 |  |
| market_mode_extreme_reversion | 17 | 11.76% | 0.2000 | -0.7059 | -12.00 | YES |
| ban_pullback_impulse_if_htf_short | 30 | 20.00% | 0.3750 | -0.5000 | -15.00 |  |
| atr_low_bucket | 33 | 21.21% | 0.4038 | -0.4697 | -15.50 |  |
| allow_only_unknown | 27 | 22.22% | 0.4286 | -0.4444 | -12.00 |  |
| allow_only_rebound | 67 | 23.88% | 0.4706 | -0.4030 | -27.00 |  |
| ban_high_atr | 65 | 24.62% | 0.4898 | -0.3846 | -25.00 |  |
| baseline_rr15 | 98 | 26.53% | 0.5417 | -0.3367 | -33.00 |  |

## Top 10 Positive Candidates

| hypothesis | trades | winrate | PF | expectancy_R | net_R | <20 warning |
| --- | --- | --- | --- | --- | --- | --- |
| allow_only_continuation | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_continuation_only_rsi_40_65 | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_us_continuation_only | 2 | 100.00% | 3.0000 | 1.5000 | 3.00 | YES |
| allow_rebound_only_if_htf_not_short | 6 | 50.00% | 1.5000 | 0.2500 | 1.50 | YES |
| hour_20_23_msk | 4 | 50.00% | 1.5000 | 0.2500 | 1.00 | YES |
| allow_us_mid_rsi_only | 23 | 47.83% | 1.3750 | 0.1957 | 4.50 |  |
| score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |
| allow_score_90_plus | 27 | 40.74% | 1.0312 | 0.0185 | 0.50 |  |

## Improved Baseline But Remain Negative

| hypothesis | trades | winrate | PF | expectancy_R | net_R | <20 warning |
| --- | --- | --- | --- | --- | --- | --- |
| allow_pullback_impulse_only_us | 45 | 37.78% | 0.9107 | -0.0556 | -2.50 |  |
| allow_countertrend_only_in_us_session | 59 | 37.29% | 0.8919 | -0.0678 | -4.00 |  |
| allow_only_us | 51 | 37.25% | 0.8906 | -0.0686 | -3.50 |  |
| allow_rebound_only_if_rsi_mid | 19 | 36.84% | 0.8750 | -0.0789 | -1.50 | YES |
| allow_us_and_asia_only | 65 | 35.38% | 0.8214 | -0.1154 | -7.50 |  |
| allow_countertrend_only_if_rsi_mid | 51 | 35.29% | 0.8182 | -0.1176 | -6.00 |  |
| ban_rebound_without_htf_support | 37 | 35.14% | 0.8125 | -0.1216 | -4.50 |  |
| hour_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| allow_17_20_msk | 46 | 34.78% | 0.8000 | -0.1304 | -6.00 |  |
| allow_us_unknown | 49 | 34.69% | 0.7969 | -0.1327 | -6.50 |  |
| ban_rsi_below_40 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| ban_unclear_low_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_only_mid_rsi | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_55 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_rsi_40_65 | 50 | 34.00% | 0.7727 | -0.1500 | -7.50 |  |
| allow_score_80_plus | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| ban_score_below_80 | 69 | 33.33% | 0.7500 | -0.1667 | -11.50 |  |
| allow_rsi_45_60 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| ban_rsi_below_45 | 30 | 33.33% | 0.7500 | -0.1667 | -5.00 |  |
| ban_rsi_below_35 | 71 | 32.39% | 0.7188 | -0.1901 | -13.50 |  |
| ban_rebound | 31 | 32.26% | 0.7143 | -0.1935 | -6.00 |  |
| ban_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| ban_unclear_overlap | 78 | 30.77% | 0.6667 | -0.2308 | -18.00 |  |
| allow_long_only_if_htf_not_short | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| ban_htf_short_for_15m_long | 13 | 30.77% | 0.6667 | -0.2308 | -3.00 | YES |
| atr_high_bucket | 33 | 30.30% | 0.6522 | -0.2424 | -8.00 |  |
| ban_rsi_below_38 | 60 | 30.00% | 0.6429 | -0.2500 | -15.00 |  |
| market_mode_pullback_impulse | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_extreme_reversion | 81 | 29.63% | 0.6316 | -0.2593 | -21.00 |  |
| ban_hours_before_14_msk | 71 | 29.58% | 0.6300 | -0.2606 | -18.50 |  |
| ban_unclear_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_rebound_europe | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_europe_rebound | 88 | 29.55% | 0.6290 | -0.2614 | -23.00 |  |
| ban_unclear_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_europe | 85 | 29.41% | 0.6250 | -0.2647 | -22.50 |  |
| ban_low_atr | 65 | 29.23% | 0.6196 | -0.2692 | -17.50 |  |
| ban_low_rsi_europe | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_europe_low_rsi | 89 | 29.21% | 0.6190 | -0.2697 | -24.00 |  |
| ban_overlap_unknown | 90 | 28.89% | 0.6094 | -0.2778 | -25.00 |  |
| score_80_90 | 42 | 28.57% | 0.6000 | -0.2857 | -12.00 |  |
| low_atr_rebound_toxic | 74 | 28.38% | 0.5943 | -0.2905 | -21.50 |  |
| ban_unknown_setup | 71 | 28.17% | 0.5882 | -0.2958 | -21.00 |  |
| atr_mid_bucket | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| allow_mid_atr_only | 32 | 28.12% | 0.5870 | -0.2969 | -9.50 |  |
| ban_overlap_rebound | 86 | 27.91% | 0.5806 | -0.3023 | -26.00 |  |
| low_atr_unknown_toxic | 90 | 27.78% | 0.5769 | -0.3056 | -27.50 |  |
| ban_europe_unknown | 96 | 27.08% | 0.5571 | -0.3229 | -31.00 |  |
| high_atr_rebound_toxic | 78 | 26.92% | 0.5526 | -0.3269 | -25.50 |  |
| allow_15_20_msk | 64 | 26.56% | 0.5426 | -0.3359 | -21.50 |  |

## Positive But Too Small To Trust

| hypothesis | trades | winrate | PF | expectancy_R | net_R | <20 warning |
| --- | --- | --- | --- | --- | --- | --- |
| allow_only_continuation | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_rebound_only_if_htf_not_short | 6 | 50.00% | 1.5000 | 0.2500 | 1.50 | YES |
| allow_continuation_only_rsi_40_65 | 4 | 100.00% | 6.0000 | 1.5000 | 6.00 | YES |
| allow_us_continuation_only | 2 | 100.00% | 3.0000 | 1.5000 | 3.00 | YES |
| hour_20_23_msk | 4 | 50.00% | 1.5000 | 0.2500 | 1.00 | YES |

## Symbol Leaderboard

| symbol | trades | winrate | PF | expectancy_R | net_R |
| --- | --- | --- | --- | --- | --- |
| ICPUSDT | 2 | 100.00% | 3.0000 | 1.5000 | 3.00 |
| KASUSDT | 5 | 60.00% | 2.2500 | 0.5000 | 2.50 |
| GMXUSDT | 1 | 100.00% | 1.5000 | 1.5000 | 1.50 |
| GRTUSDT | 6 | 50.00% | 1.5000 | 0.2500 | 1.50 |
| ETHUSDT | 1 | 100.00% | 1.5000 | 1.5000 | 1.50 |
| INJUSDT | 2 | 50.00% | 1.5000 | 0.2500 | 0.50 |
| SUIUSDT | 2 | 50.00% | 1.5000 | 0.2500 | 0.50 |
| XRPUSDT | 2 | 50.00% | 1.5000 | 0.2500 | 0.50 |
| SOLUSDT | 2 | 50.00% | 1.5000 | 0.2500 | 0.50 |
| FILUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| ETCUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| ARBUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| CRVUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| STXUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| SEIUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| AVAXUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| DYDXUSDT | 3 | 33.33% | 0.7500 | -0.1667 | -0.50 |
| ENAUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| APTUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| ATOMUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| LTCUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| OPUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| JUPUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| BNBUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| NEARUSDT | 1 | 0.00% | 0.0000 | -1.0000 | -1.00 |
| UNIUSDT | 4 | 25.00% | 0.5000 | -0.3750 | -1.50 |
| DOGEUSDT | 2 | 0.00% | 0.0000 | -1.0000 | -2.00 |
| ADAUSDT | 2 | 0.00% | 0.0000 | -1.0000 | -2.00 |
| SNXUSDT | 2 | 0.00% | 0.0000 | -1.0000 | -2.00 |
| RUNEUSDT | 2 | 0.00% | 0.0000 | -1.0000 | -2.00 |
| DOTUSDT | 5 | 20.00% | 0.3750 | -0.5000 | -2.50 |
| LINKUSDT | 5 | 20.00% | 0.3750 | -0.5000 | -2.50 |
| IMXUSDT | 5 | 20.00% | 0.3750 | -0.5000 | -2.50 |
| BCHUSDT | 3 | 0.00% | 0.0000 | -1.0000 | -3.00 |
| ORDIUSDT | 3 | 0.00% | 0.0000 | -1.0000 | -3.00 |
| XLMUSDT | 3 | 0.00% | 0.0000 | -1.0000 | -3.00 |
| AAVEUSDT | 3 | 0.00% | 0.0000 | -1.0000 | -3.00 |
| TIAUSDT | 4 | 0.00% | 0.0000 | -1.0000 | -4.00 |

## Large Caps Vs Alts

| group | trades | winrate | PF | expectancy_R | net_R |
| --- | --- | --- | --- | --- | --- |
| large_caps | 22 | 22.73% | 0.4412 | -0.4318 | -9.50 |
| alts | 76 | 27.63% | 0.5727 | -0.3092 | -23.50 |

## Interpretation Safety

- Improvements are historical old-sample observations only.
- Negative candidates remain negative and are not production-ready.
- Any hypothesis with fewer than 20 trades is explicitly marked.
- Rejected-signal conclusions require rejected_signals outcomes.
- Prospective validity requires live paper.
- Stability requires a new production sample.
- Nothing in Research Pack 2 may be moved to production yet.

## Safety

- Production Crypto13 was not touched.
- Binance API/live paper was not started.
- No real or testnet orders were added or sent.